package com.example.cnnnews;

import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements  GetCNNAsyncTask.IData,GetImageAsyncTask.IImage {
    LinearLayout vertical;
    ArrayList<Cnn> arrayList;
   // ImageView iv;
    int index = 0;
    ImageButton f,p,n,l;
    Button fish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        vertical = (LinearLayout) findViewById(R.id.vertical);
       // iv= (ImageView) findViewById(R.id.imageView);

        f= (ImageButton) findViewById(R.id.first_button);
        f.setEnabled(false);
        p= (ImageButton) findViewById(R.id.previous_button);
        p.setEnabled(false);
        n= (ImageButton) findViewById(R.id.next_button);
        n.setEnabled(false);
        l= (ImageButton) findViewById(R.id.last_button);
        l.setEnabled(false);
        fish= (Button) findViewById(R.id.finish_button);
        fish.setEnabled(false);



        findViewById(R.id.first_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cnn n = arrayList.get(0);
                setData(n);
                index = 0;
            }
        });
        findViewById(R.id.previous_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (arrayList != null) {
                    if (index > 0) {
                        index--;
                        Cnn n = arrayList.get(index);
                        setData(n);
                    }
                }

            }
        });
        findViewById(R.id.next_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (arrayList != null) {
                    if (index < arrayList.size() - 1) {
                        index++;
                        Cnn n = arrayList.get(index);
                        setData(n);
                    }
                }

            }
        });
        findViewById(R.id.finish_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.last_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(arrayList!=null){

                    Cnn n = arrayList.get(arrayList.size()-1);
                    setData(n);
                    index = arrayList.size()-1;
                }

            }
        });


        findViewById(R.id.getnews_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                f.setEnabled(true); p.setEnabled(true); n.setEnabled(true);l.setEnabled(true);fish.setEnabled(true);
                new GetCNNAsyncTask(MainActivity.this).execute("http://rss.cnn.com/rss/cnn_tech.rss");
            }
        });

    }

    @Override
    public void onGetNews(ArrayList<Cnn> al) {
        arrayList = al;
        Cnn cnn = al.get(0);
        setData(cnn);


    }

    public void setData(Cnn c) {
        TextView title = new TextView(this);
        TextView pubdate = new TextView(this);
        TextView desc = new TextView(this);
        title.setText(c.getTitle().toString());
        pubdate.setText("Published on :" + c.getPubdate().toString());
        desc.setText("Description : \n" + c.getDesc().toString());
        vertical.removeAllViews();
        vertical.addView(title);
        vertical.addView(pubdate);
        vertical.addView(desc);
        new GetImageAsyncTask(MainActivity.this).execute(c.getLink().toString());

    }
  @Override
    public void onGetImage(Bitmap al) {
        ImageView iv= (ImageView) findViewById(R.id.imageView);
    iv.setImageBitmap(al);
    }
}

