package com.example.cnnnews;

public class Cnn {
    String title;
    String link;
    String desc;

    public String getTitle() {
        return title;
    }

    @Override
    public String toString() {
        return "Cnn{" +
                "title='" + title + '\'' +
                ", link='" + link + '\'' +
                ", desc='" + desc + '\'' +
                ", pubdate='" + pubdate + '\'' +
                '}';
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String guid) {
        this.desc = guid;
    }

    public String getPubdate() {
        return pubdate;
    }

    public void setPubdate(String pubdate) {
        this.pubdate = pubdate;
    }

    String pubdate;
}
